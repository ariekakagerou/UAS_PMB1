import { Component } from '@angular/core';
import axios from 'axios';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page {

  public data: any[] = [];
  public results: any[] = [];

  // Variabel allData untuk array data dari database
  public allData: any[] = [];

  constructor() {
    
    // Form Load GetData
    this.GetData();
  }

  handleInput(event: any) {
    const query = event.target.value.toLowerCase();
    if (!query) {
      this.results = this.allData; // Jika query kosong, tampilkan semua data
    } else {
      this.results = this.allData.filter((d: any) =>
        d.nama_lengkap.toLowerCase().includes(query) ||
        d.reg_id.toLowerCase().includes(query) ||
        d.email.toLowerCase().includes(query)
      );
    }
  }

  handleRefresh(event: any) {
    setTimeout(() => {
      // Any calls to load data go here
      event.target.complete();
      this.GetData();
    }, 2000);
  }

  // Function GetData from API
  async GetData() {
    try {
      const res: any = await axios.get('https://praktikum-cpanel-unbin.com/api_ari_eka/api_uas/get_data_mahasiswa.php');
      console.log(res.data);
      this.allData = res.data.result;
      this.results = this.allData; // Set results to allData initially for full display
    } catch (error) {
      console.error('Error fetching data:', error);
      // Handle error accordingly (e.g., show error message to the user)
    }
  }
}
