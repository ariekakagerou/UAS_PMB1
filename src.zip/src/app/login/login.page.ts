import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {

  username: string = '1234';
  password: string = '1234';
  loginDisabled: boolean = true;

  constructor(
    private router: Router,
    private alertController: AlertController
  ) { }

  checkInputs() {
    this.loginDisabled = !(this.username && this.password);
  }

  async loginUser() {
    if (this.username === '1234' && this.password === '1234') {
      this.router.navigate(['/tabs/tab1']);
    } else {
      const alert = await this.alertController.create({
        header: 'Login Failed',
        message: 'Incorrect username or password',
        buttons: ['OK']
      });
      await alert.present();
    }
  }
}
